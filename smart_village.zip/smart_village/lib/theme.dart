import 'package:flutter/material.dart';

class AppTheme {
  // Primary Royal Blue matching the Image 2 UI
  static const Color primaryBlue = Color(0xFF0066FF);
  static const Color primaryDark = Color(0xFF0F172A);
  static const Color backgroundLight = Color(0xFFF8FAFC);
  
  // Category Tile Accent Colors (Image 2)
  static const Color rsRed = Color(0xFFEF4444);        // Rumah Sakit (Red)
  static const Color puskesmasGreen = Color(0xFF10B981);// Puskesmas (Green)
  static const Color klinikBlue = Color(0xFF3B82F6);    // Klinik (Blue)
  static const Color semuaOrange = Color(0xFFF59E0B);   // Semua (Orange)

  // Status Badge Colors
  static const Color openGreenBg = Color(0xFFDCFCE7);
  static const Color openGreenText = Color(0xFF15803D);
  static const Color ratingGold = Color(0xFFF59E0B);

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryBlue,
        primary: primaryBlue,
        secondary: primaryDark,
        surface: Colors.white,
      ),
      scaffoldBackgroundColor: backgroundLight,
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        scrolledUnderElevation: 0,
        iconTheme: IconThemeData(color: primaryDark),
        titleTextStyle: TextStyle(
          color: primaryDark,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 1,
        shadowColor: Colors.black.withOpacity(0.04),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        color: Colors.white,
      ),
    );
  }
}
