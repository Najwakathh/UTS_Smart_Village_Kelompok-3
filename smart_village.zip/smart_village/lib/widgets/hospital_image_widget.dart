import 'package:flutter/material.dart';
import '../theme.dart';

class HospitalImageWidget extends StatelessWidget {
  final String category;
  final double width;
  final double height;
  final double borderRadius;

  const HospitalImageWidget({
    super.key,
    required this.category,
    this.width = 70,
    this.height = 70,
    this.borderRadius = 12,
  });

  @override
  Widget build(BuildContext context) {
    Color cardBgColor;
    Color iconColor;
    IconData mainIcon;

    if (category == 'Rumah Sakit') {
      cardBgColor = AppTheme.rsRed;
      iconColor = Colors.white;
      mainIcon = Icons.local_hospital_rounded;
    } else if (category == 'Puskesmas') {
      cardBgColor = AppTheme.puskesmasGreen;
      iconColor = Colors.white;
      mainIcon = Icons.add_box_rounded;
    } else {
      cardBgColor = AppTheme.klinikBlue;
      iconColor = Colors.white;
      mainIcon = Icons.medical_services_rounded;
    }

    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: cardBgColor.withOpacity(0.12),
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(color: cardBgColor.withOpacity(0.3), width: 1.5),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: CustomPaint(
          painter: HospitalThumbnailPainter(
            categoryColor: cardBgColor,
          ),
          child: Center(
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: cardBgColor,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 4,
                  ),
                ],
              ),
              child: Icon(mainIcon, color: iconColor, size: height * 0.35),
            ),
          ),
        ),
      ),
    );
  }
}

class HospitalThumbnailPainter extends CustomPainter {
  final Color categoryColor;

  HospitalThumbnailPainter({required this.categoryColor});

  @override
  void paint(Canvas canvas, Size size) {
    // Sky Background Gradient
    final Paint bgPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          categoryColor.withOpacity(0.15),
          categoryColor.withOpacity(0.05),
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bgPaint);

    // Building silhouette
    final Paint buildingPaint = Paint()..color = categoryColor.withOpacity(0.2);
    canvas.drawRect(
      Rect.fromLTWH(size.width * 0.2, size.height * 0.4, size.width * 0.6, size.height * 0.6),
      buildingPaint,
    );

    // Roof
    final Path roofPath = Path()
      ..moveTo(size.width * 0.15, size.height * 0.4)
      ..lineTo(size.width * 0.5, size.height * 0.2)
      ..lineTo(size.width * 0.85, size.height * 0.4)
      ..close();
    canvas.drawPath(roofPath, buildingPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
