import '../models/facility.dart';

class FacilityData {
  static const double desaCenterLat = -6.2088;
  static const double desaCenterLng = 106.8456;
  static const String desaName = "Kabupaten X";

  static List<Facility> getInitialFacilities() {
    return [
      Facility(
        id: '1',
        name: 'RSUD Kabupaten X',
        category: 'Rumah Sakit',
        subCategory: 'Rumah Sakit Umum Daerah',
        rating: 4.5,
        reviewCount: 120,
        address: 'Jl. Raya Kabupaten X No. 10, Desa Sukamaju, Kec. X, Kab. X',
        phone: '(021) 555-0199',
        operatingHours: 'Buka - 24 jam',
        latitude: -6.2075,
        longitude: 106.8430,
        imageUrl: 'https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?w=600',
        services: [
          'Poliklinik',
          'IGD',
          'Rawat Inap',
          'Laboratorium',
          'Radiologi',
          'Farmasi',
          'Rehabilitasi',
          'Lainnya'
        ],
        description:
            'RSUD Kabupaten X adalah rumah sakit pusat pelayanan kesehatan daerah yang dilengkapi fasilitas IGD 24 Jam, ICU, Poliklinik Spesialis, serta laboratorium diagnostik terkini.',
        is24Hours: true,
        isFavorite: true,
      ),
      Facility(
        id: '2',
        name: 'Puskesmas Sukamaju',
        category: 'Puskesmas',
        subCategory: 'Puskesmas Kecamatan',
        rating: 4.3,
        reviewCount: 86,
        address: 'Jl. Desa Sukamaju No. 15, Kec. X, Kab. X',
        phone: '(021) 555-0344',
        operatingHours: 'Buka 08:00 - 16:00',
        latitude: -6.2140,
        longitude: 106.8510,
        imageUrl: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=600',
        services: ['Umum', 'KIA', 'Imunisasi', 'Laboratorium'],
        description:
            'Puskesmas Sukamaju melayani pemeriksaan kesehatan dasar, posyandu, imunisasi anak, dan konsultasi kesehatan keluarga.',
        is24Hours: false,
        isFavorite: false,
      ),
      Facility(
        id: '3',
        name: 'Klinik Sehat Mandiri',
        category: 'Klinik',
        subCategory: 'Klinik Pratama',
        rating: 4.2,
        reviewCount: 64,
        address: 'Jl. Merdeka No. 42, Kec. X, Kab. X',
        phone: '(021) 555-0566',
        operatingHours: 'Buka 07:00 - 21:00',
        latitude: -6.2030,
        longitude: 106.8490,
        imageUrl: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=600',
        services: ['Umum', 'Gigi', 'Laboratorium'],
        description:
            'Klinik Sehat Mandiri menyediakan layanan dokter umum, kesehatan gigi, tes gula darah, dan pemeriksaan kesehatan rutin.',
        is24Hours: false,
        isFavorite: true,
      ),
      Facility(
        id: '4',
        name: 'RS Harapan Bunda',
        category: 'Rumah Sakit',
        subCategory: 'Rumah Sakit Swasta',
        rating: 4.6,
        reviewCount: 98,
        address: 'Jl. Pemuda No. 88, Kec. X, Kab. X',
        phone: '(021) 555-0288',
        operatingHours: 'Buka - 24 jam',
        latitude: -6.2200,
        longitude: 106.8390,
        imageUrl: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=600',
        services: ['IGD', 'Poliklinik', 'Rawat Inap', 'Radiologi'],
        description:
            'RS Harapan Bunda mengutamakan pelayanan kesehatan ibu, anak, dan gawat darurat dengan ruang perawatan yang nyaman.',
        is24Hours: true,
        isFavorite: true,
      ),
    ];
  }
}
