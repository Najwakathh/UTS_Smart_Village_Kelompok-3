class Facility {
  final String id;
  final String name;
  final String category; // 'Rumah Sakit', 'Puskesmas', 'Klinik'
  final String subCategory;
  final double rating;
  final int reviewCount;
  final String address;
  final String phone;
  final String operatingHours;
  final double latitude;
  final double longitude;
  final String imageUrl;
  final List<String> services;
  final String description;
  final bool is24Hours;
  bool isFavorite;
  
  // Dynamic LBS properties
  double distanceInKm;
  bool isInGeofence;

  Facility({
    required this.id,
    required this.name,
    required this.category,
    required this.subCategory,
    required this.rating,
    required this.reviewCount,
    required this.address,
    required this.phone,
    required this.operatingHours,
    required this.latitude,
    required this.longitude,
    required this.imageUrl,
    required this.services,
    required this.description,
    this.is24Hours = true,
    this.isFavorite = false,
    this.distanceInKm = 0.0,
    this.isInGeofence = true,
  });
}
