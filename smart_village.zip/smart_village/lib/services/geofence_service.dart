import '../data/facility_data.dart';
import 'location_service.dart';

class GeofenceService {
  // Geofence configuration for Desa X
  final double centerLat = FacilityData.desaCenterLat;
  final double centerLng = FacilityData.desaCenterLng;
  final double radiusKm = 4.5; // 4.5 km radius geofence zone for Desa X
  final String zoneName = "Wilayah Smart Village Desa X";

  static final GeofenceService _instance = GeofenceService._internal();
  factory GeofenceService() => _instance;
  GeofenceService._internal();

  /// Check if a coordinate is within the active Geofence boundary
  bool isWithinGeofence(double lat, double lng) {
    double distance = LocationService.calculateDistance(
      centerLat,
      centerLng,
      lat,
      lng,
    );
    return distance <= radiusKm;
  }

  /// Get distance from Geofence center point
  double getDistanceFromCenter(double lat, double lng) {
    return LocationService.calculateDistance(
      centerLat,
      centerLng,
      lat,
      lng,
    );
  }

  /// Get human-readable Geofence status string
  String getGeofenceStatus(double lat, double lng) {
    if (isWithinGeofence(lat, lng)) {
      return "Dalam Jangkauan Desa X";
    } else {
      return "Luar Jangkauan Geofence";
    }
  }
}
