import 'dart:math';
import '../data/facility_data.dart';

class LocationService {
  // Current user latitude & longitude (defaulted to Desa X center area)
  double currentUserLat = FacilityData.desaCenterLat;
  double currentUserLng = FacilityData.desaCenterLng;

  // Singleton instance
  static final LocationService _instance = LocationService._internal();
  factory LocationService() => _instance;
  LocationService._internal();

  /// Calculate distance between two coordinates using Haversine Formula in kilometers
  static double calculateDistance(
      double lat1, double lon1, double lat2, double lon2) {
    const double earthRadiusKm = 6371.0;

    double dLat = _degreesToRadians(lat2 - lat1);
    double dLon = _degreesToRadians(lon2 - lon1);

    double a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_degreesToRadians(lat1)) *
            cos(_degreesToRadians(lat2)) *
            sin(dLon / 2) *
            sin(dLon / 2);

    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return earthRadiusKm * c;
  }

  static double _degreesToRadians(double degrees) {
    return degrees * pi / 180.0;
  }

  /// Format distance into friendly string representation
  static String formatDistance(double distanceInKm) {
    if (distanceInKm < 1.0) {
      int meters = (distanceInKm * 1000).round();
      return '$meters m';
    } else {
      return '${distanceInKm.toStringAsFixed(1)} km';
    }
  }

  /// Update current simulated user position
  void updateUserPosition(double lat, double lng) {
    currentUserLat = lat;
    currentUserLng = lng;
  }
}
