import 'package:flutter/material.dart';
import '../models/facility.dart';
import '../data/facility_data.dart';
import '../theme.dart';
import '../services/location_service.dart';
import '../services/geofence_service.dart';
import '../widgets/hospital_image_widget.dart';
import 'facility_detail_screen.dart';

class FacilityListScreen extends StatefulWidget {
  final String? initialCategory;
  final Function(Facility)? onSelectFacilityOnMap;

  const FacilityListScreen({
    super.key,
    this.initialCategory,
    this.onSelectFacilityOnMap,
  });

  @override
  State<FacilityListScreen> createState() => _FacilityListScreenState();
}

class _FacilityListScreenState extends State<FacilityListScreen> {
  late List<Facility> _allFacilities;
  late List<Facility> _filteredFacilities;
  String _selectedCategory = 'Semua';
  String _searchQuery = '';

  final locationService = LocationService();
  final geofenceService = GeofenceService();

  @override
  void initState() {
    super.initState();
    _selectedCategory = widget.initialCategory ?? 'Semua';
    _loadAndCalculateFacilities();
  }

  void _loadAndCalculateFacilities() {
    _allFacilities = FacilityData.getInitialFacilities();
    for (var f in _allFacilities) {
      f.distanceInKm = LocationService.calculateDistance(
        locationService.currentUserLat,
        locationService.currentUserLng,
        f.latitude,
        f.longitude,
      );
      f.isInGeofence = geofenceService.isWithinGeofence(f.latitude, f.longitude);
    }
    _allFacilities.sort((a, b) => a.distanceInKm.compareTo(b.distanceInKm));
    _applyFilters();
  }

  void _applyFilters() {
    setState(() {
      _filteredFacilities = _allFacilities.where((f) {
        final matchesCategory = _selectedCategory == 'Semua' ||
            f.category.toLowerCase() == _selectedCategory.toLowerCase();
        final matchesQuery = f.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            f.services.any((s) => s.toLowerCase().contains(_searchQuery.toLowerCase()));
        return matchesCategory && matchesQuery;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Lokasi'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Filter Chips (Semua, Rumah Sakit, Puskesmas, Klinik)
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  'Semua',
                  'Rumah Sakit',
                  'Puskesmas',
                  'Klinik',
                ].map((category) {
                  final isSelected = _selectedCategory == category;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: FilterChip(
                      selected: isSelected,
                      label: Text(category),
                      selectedColor: AppTheme.primaryBlue,
                      backgroundColor: Colors.grey.shade100,
                      labelStyle: TextStyle(
                        color: isSelected ? Colors.white : AppTheme.primaryDark,
                        fontWeight:
                            isSelected ? FontWeight.bold : FontWeight.normal,
                        fontSize: 12,
                      ),
                      checkmarkColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide.none,
                      ),
                      onSelected: (selected) {
                        setState(() {
                          _selectedCategory = category;
                          _applyFilters();
                        });
                      },
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          const SizedBox(height: 8),

          // Facilities List (Matching Image 2 Screen 4)
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              itemCount: _filteredFacilities.length,
              itemBuilder: (context, index) {
                final facility = _filteredFacilities[index];
                return _buildFacilityCard(context, facility);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFacilityCard(BuildContext context, Facility facility) {
    final String distanceStr =
        LocationService.formatDistance(facility.distanceInKm);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => FacilityDetailScreen(facility: facility),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Offline & Online Robust Thumbnail
              HospitalImageWidget(
                category: facility.category,
                width: 75,
                height: 75,
                borderRadius: 12,
              ),
              const SizedBox(width: 12),

              // Content Details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      facility.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: AppTheme.primaryDark,
                      ),
                    ),
                    const SizedBox(height: 4),

                    // Distance, Rating, Operating Status Row
                    Row(
                      children: [
                        const Icon(Icons.near_me,
                            size: 12, color: AppTheme.primaryBlue),
                        const SizedBox(width: 2),
                        Text(
                          distanceStr,
                          style: const TextStyle(
                              fontSize: 11, color: Colors.grey),
                        ),
                        const SizedBox(width: 8),
                        const Icon(Icons.star,
                            size: 12, color: AppTheme.ratingGold),
                        const SizedBox(width: 2),
                        Text(
                          '${facility.rating} (${facility.reviewCount})',
                          style: const TextStyle(
                              fontSize: 11, color: Colors.grey),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppTheme.openGreenBg,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text(
                            '🟢 Buka',
                            style: TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: AppTheme.openGreenText,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),

                    // Service Chips Wrap
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: facility.services.map((service) {
                          return Container(
                            margin: const EdgeInsets.only(right: 4),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade100,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              service,
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.grey[700],
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 4),
              const Icon(Icons.chevron_right, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}
