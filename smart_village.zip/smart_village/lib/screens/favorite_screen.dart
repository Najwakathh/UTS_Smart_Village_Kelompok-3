import 'package:flutter/material.dart';
import '../models/facility.dart';
import '../data/facility_data.dart';
import '../theme.dart';
import '../services/location_service.dart';
import 'facility_detail_screen.dart';

class FavoriteScreen extends StatefulWidget {
  const FavoriteScreen({super.key});

  @override
  State<FavoriteScreen> createState() => _FavoriteScreenState();
}

class _FavoriteScreenState extends State<FavoriteScreen> {
  late List<Facility> _favoriteFacilities;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  void _loadFavorites() {
    final list = FacilityData.getInitialFacilities();
    for (var f in list) {
      f.distanceInKm = LocationService.calculateDistance(
        LocationService().currentUserLat,
        LocationService().currentUserLng,
        f.latitude,
        f.longitude,
      );
    }
    setState(() {
      _favoriteFacilities = list.where((f) => f.isFavorite).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Favorit'),
        centerTitle: true,
      ),
      body: _favoriteFacilities.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.favorite_border, size: 64, color: Colors.grey[400]),
                  const SizedBox(height: 12),
                  Text(
                    'Belum ada fasilitas favorit disimpan',
                    style: TextStyle(color: Colors.grey[600], fontSize: 14),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _favoriteFacilities.length,
              itemBuilder: (context, index) {
                final facility = _favoriteFacilities[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(12),
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.network(
                        facility.imageUrl,
                        width: 60,
                        height: 60,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) => Container(
                          width: 60,
                          height: 60,
                          color: AppTheme.primaryBlue.withOpacity(0.1),
                          child: const Icon(Icons.local_hospital,
                              color: AppTheme.primaryBlue),
                        ),
                      ),
                    ),
                    title: Text(
                      facility.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: AppTheme.primaryDark,
                      ),
                    ),
                    subtitle: Text(
                      '${LocationService.formatDistance(facility.distanceInKm)} • ${facility.category}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.favorite, color: Colors.red),
                      onPressed: () {
                        setState(() {
                          facility.isFavorite = false;
                          _favoriteFacilities.removeAt(index);
                        });
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                                '${facility.name} dihapus dari favorit'),
                            duration: const Duration(seconds: 1),
                          ),
                        );
                      },
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              FacilityDetailScreen(facility: facility),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}
