import 'package:flutter/material.dart';
import '../models/facility.dart';
import '../data/facility_data.dart';
import '../theme.dart';
import 'facility_detail_screen.dart';

class GeofenceAlertScreen extends StatelessWidget {
  final Facility? facility;

  const GeofenceAlertScreen({super.key, this.facility});

  @override
  Widget build(BuildContext context) {
    final targetFacility = facility ?? FacilityData.getInitialFacilities()[1]; // Puskesmas Sukamaju

    return Scaffold(
      body: Stack(
        children: [
          // Map Background with Geofence Circle Radius (Matching Screen 10)
          CustomPaint(
            size: Size.infinite,
            painter: GeofenceModalMapPainter(),
          ),

          // Top "Radius 500 m" Pill Badge
          Positioned(
            top: 50,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: const Text(
                  'Radius 500 m',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.primaryBlue,
                  ),
                ),
              ),
            ),
          ),

          // Top Back Arrow Button
          Positioned(
            top: 44,
            left: 16,
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: const Icon(Icons.arrow_back, color: AppTheme.primaryDark),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ),

          // Bottom Sheet Card Modal (Matching Screen 10)
          Positioned(
            bottom: 24,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 20,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Close X Button on top right
                  Align(
                    alignment: Alignment.topRight,
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: const Icon(Icons.close, color: Colors.grey, size: 20),
                    ),
                  ),

                  // Green Circular Pin Badge Icon (Matching Screen 10)
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFDCFCE7),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.location_on,
                      color: Color(0xFF16A34A),
                      size: 40,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Title: "Anda Masuk Area Geofencing"
                  const Text(
                    'Anda Masuk Area Geofencing',
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryDark,
                    ),
                  ),
                  const SizedBox(height: 8),

                  // Text: "Selamat! Anda telah memasuki area Puskesmas Sukamaju (radius 500 m)."
                  Text(
                    'Selamat! Anda telah memasuki area ${targetFacility.name} (radius 500 m).',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.grey[700],
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Primary Button (Full width Royal Blue): "Lihat Lokasi"
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                FacilityDetailScreen(facility: targetFacility),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryBlue,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                      child: const Text(
                        'Lihat Lokasi',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),

                  // Secondary Button (Outlined/Text): "Tutup"
                  SizedBox(
                    width: double.infinity,
                    height: 44,
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.grey[700],
                        side: BorderSide(color: Colors.grey.shade300),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(22),
                        ),
                      ),
                      child: const Text(
                        'Tutup',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class GeofenceModalMapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Map Canvas
    final Paint bgPaint = Paint()..color = const Color(0xFFE2E8F0);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    // Roads
    final Paint roadPaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 8.0;

    for (double i = 0; i < size.width; i += 60) {
      canvas.drawLine(Offset(i, 0), Offset(i, size.height), roadPaint);
    }
    for (double j = 0; j < size.height; j += 60) {
      canvas.drawLine(Offset(0, j), Offset(size.width, j), roadPaint);
    }

    // Geofence Circle Radius (Blue)
    final Offset center = Offset(size.width / 2, size.height * 0.38);
    const double radius = 130;

    final Paint fillPaint = Paint()..color = AppTheme.primaryBlue.withOpacity(0.12);
    final Paint borderPaint = Paint()
      ..color = AppTheme.primaryBlue
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    canvas.drawCircle(center, radius, fillPaint);
    canvas.drawCircle(center, radius, borderPaint);

    // Red Center Cross Pin
    canvas.drawCircle(center, 12, Paint()..color = Colors.red);
    canvas.drawCircle(center, 5, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
