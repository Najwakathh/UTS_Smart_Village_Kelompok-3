import 'package:flutter/material.dart';
import '../models/facility.dart';
import '../data/facility_data.dart';
import '../theme.dart';
import '../services/location_service.dart';
import '../services/geofence_service.dart';
import 'facility_detail_screen.dart';

class MapScreen extends StatefulWidget {
  final Facility? preselectedFacility;

  const MapScreen({super.key, this.preselectedFacility});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  late List<Facility> _facilities;
  late List<Facility> _filteredFacilities;
  String _selectedCategory = 'Semua';
  Facility? _selectedFacility;

  final locationService = LocationService();
  final geofenceService = GeofenceService();

  @override
  void initState() {
    super.initState();
    _facilities = FacilityData.getInitialFacilities();
    _recalculateDistances();
    _applyFilter();
    if (widget.preselectedFacility != null) {
      _selectedFacility = widget.preselectedFacility;
    } else if (_facilities.isNotEmpty) {
      _selectedFacility = _facilities.first;
    }
  }

  void _recalculateDistances() {
    for (var f in _facilities) {
      f.distanceInKm = LocationService.calculateDistance(
        locationService.currentUserLat,
        locationService.currentUserLng,
        f.latitude,
        f.longitude,
      );
      f.isInGeofence = geofenceService.isWithinGeofence(f.latitude, f.longitude);
    }
  }

  void _applyFilter() {
    setState(() {
      _filteredFacilities = _facilities.where((f) {
        if (_selectedCategory == 'Semua') return true;
        if (_selectedCategory == 'RS') return f.category == 'Rumah Sakit';
        return f.category.toLowerCase() == _selectedCategory.toLowerCase();
      }).toList();
    });
  }

  void _showGeofenceModal(Facility facility) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.location_on,
                  color: Colors.green,
                  size: 36,
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Anda Masuk Area Geofencing',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryDark,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Selamat! Anda telah memasuki area ${facility.name} (radius 500 m).',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Colors.grey[700]),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            FacilityDetailScreen(facility: facility),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryBlue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24),
                    ),
                  ),
                  child: const Text(
                    'Lihat Lokasi',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Tutup', style: TextStyle(color: Colors.grey)),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Peta Lokasi'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.layers_outlined),
            onPressed: () {
              if (_selectedFacility != null) {
                _showGeofenceModal(_selectedFacility!);
              }
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          // Map Canvas Painter
          GestureDetector(
            onTapDown: (details) {
              final Size size = MediaQuery.of(context).size;
              double normX = (details.localPosition.dx / size.width) - 0.5;
              double normY = (details.localPosition.dy / size.height) - 0.5;
              setState(() {
                locationService.currentUserLat =
                    FacilityData.desaCenterLat + (normY * 0.04);
                locationService.currentUserLng =
                    FacilityData.desaCenterLng + (normX * 0.04);
                _recalculateDistances();
              });

              if (_facilities.isNotEmpty) {
                _showGeofenceModal(_facilities.first);
              }
            },
            child: CustomPaint(
              size: Size.infinite,
              painter: MapPainter(
                facilities: _filteredFacilities,
                selectedFacility: _selectedFacility,
                userLat: locationService.currentUserLat,
                userLng: locationService.currentUserLng,
              ),
            ),
          ),

          // Top Search & Filter Bar Overlay (Matching Image 2 Screen 3)
          Positioned(
            top: 12,
            left: 16,
            right: 16,
            child: Column(
              children: [
                // Search Input
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.search, color: Colors.grey, size: 20),
                      const SizedBox(width: 10),
                      Text(
                        'Cari lokasi...',
                        style: TextStyle(
                            color: Colors.grey[400], fontSize: 13),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // Filter Chips (Semua, RS, Puskesmas, Klinik)
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: ['Semua', 'RS', 'Puskesmas', 'Klinik'].map((cat) {
                      bool isSelected = _selectedCategory == cat;
                      return Padding(
                        padding: const EdgeInsets.only(right: 6.0),
                        child: FilterChip(
                          selected: isSelected,
                          label: Text(cat),
                          selectedColor: AppTheme.primaryBlue,
                          backgroundColor: Colors.white,
                          labelStyle: TextStyle(
                            color: isSelected
                                ? Colors.white
                                : AppTheme.primaryDark,
                            fontWeight: isSelected
                                ? FontWeight.bold
                                : FontWeight.normal,
                            fontSize: 11,
                          ),
                          checkmarkColor: Colors.white,
                          onSelected: (selected) {
                            setState(() {
                              _selectedCategory = cat;
                              _applyFilter();
                            });
                          },
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),

          // Bottom Facility Selected Card
          if (_selectedFacility != null)
            Positioned(
              bottom: 20,
              left: 16,
              right: 16,
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          _selectedFacility!.imageUrl,
                          width: 60,
                          height: 60,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Container(
                            width: 60,
                            height: 60,
                            color: AppTheme.primaryBlue.withOpacity(0.1),
                            child: const Icon(Icons.local_hospital,
                                color: AppTheme.primaryBlue),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _selectedFacility!.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                                color: AppTheme.primaryDark,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '📍 ${LocationService.formatDistance(_selectedFacility!.distanceInKm)} • ⭐ ${_selectedFacility!.rating}',
                              style: TextStyle(
                                  fontSize: 12, color: Colors.grey[600]),
                            ),
                          ],
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => FacilityDetailScreen(
                                  facility: _selectedFacility!),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primaryBlue,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                        ),
                        child: const Text('Detail',
                            style: TextStyle(fontSize: 12)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class MapPainter extends CustomPainter {
  final List<Facility> facilities;
  final Facility? selectedFacility;
  final double userLat;
  final double userLng;

  MapPainter({
    required this.facilities,
    required this.selectedFacility,
    required this.userLat,
    required this.userLng,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // Map Canvas Background
    final Paint bgPaint = Paint()..color = const Color(0xFFE2E8F0);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    // Roads
    final Paint roadPaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 8.0;

    for (double i = 0; i < size.width; i += 70) {
      canvas.drawLine(Offset(i, 0), Offset(i, size.height), roadPaint);
    }
    for (double j = 0; j < size.height; j += 70) {
      canvas.drawLine(Offset(0, j), Offset(size.width, j), roadPaint);
    }

    // Geofence Circle Radius (500m / 4.5km)
    final Paint geofenceFill = Paint()
      ..color = AppTheme.primaryBlue.withOpacity(0.1);
    final Paint geofenceBorder = Paint()
      ..color = AppTheme.primaryBlue
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    canvas.drawCircle(Offset(size.width / 2, size.height / 2), 150, geofenceFill);
    canvas.drawCircle(Offset(size.width / 2, size.height / 2), 150, geofenceBorder);

    // User Dot (Blue Pulse)
    canvas.drawCircle(Offset(size.width / 2, size.height / 2), 18, Paint()..color = AppTheme.primaryBlue.withOpacity(0.2));
    canvas.drawCircle(Offset(size.width / 2, size.height / 2), 8, Paint()..color = AppTheme.primaryBlue);

    // Facility Markers (Red Pins)
    for (int i = 0; i < facilities.length; i++) {
      double x = (size.width * 0.3) + (i * 70);
      double y = (size.height * 0.35) + ((i % 2) * 80);

      canvas.drawCircle(Offset(x, y), 10, Paint()..color = Colors.red);
      canvas.drawCircle(Offset(x, y), 5, Paint()..color = Colors.white);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
