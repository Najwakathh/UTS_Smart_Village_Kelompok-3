import 'package:flutter/material.dart';
import '../models/facility.dart';
import '../theme.dart';

class RouteScreen extends StatefulWidget {
  final Facility facility;

  const RouteScreen({super.key, required this.facility});

  @override
  State<RouteScreen> createState() => _RouteScreenState();
}

class _RouteScreenState extends State<RouteScreen> {
  int _selectedTransportMode = 0; // 0: Drive, 1: Walk, 2: Bike

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Rute ke ${widget.facility.name}'),
      ),
      body: Stack(
        children: [
          // Route Map Canvas
          CustomPaint(
            size: Size.infinite,
            painter: RouteMapPainter(),
          ),

          // Top Info Card
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(14.0),
                child: Row(
                  children: [
                    const Icon(Icons.navigation, color: AppTheme.primaryBlue, size: 28),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.facility.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              color: AppTheme.primaryDark,
                            ),
                          ),
                          const SizedBox(height: 2),
                          const Text(
                            'Estimasi Waktu: 4 menit (1,2 km)',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.green,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Bottom Controls (Transport Selector + Start Navigation Button)
          Positioned(
            bottom: 20,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Transport Mode Switcher Row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildTransportOption(0, Icons.directions_car, '4 mnt', '1,2 km'),
                      _buildTransportOption(1, Icons.directions_walk, '15 mnt', '1,1 km'),
                      _buildTransportOption(2, Icons.directions_bike, '6 mnt', '1,3 km'),
                    ],
                  ),
                  const SizedBox(height: 16),

                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                                'Memulai navigasi GPS ke ${widget.facility.name}...'),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryBlue,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24),
                        ),
                      ),
                      child: const Text(
                        'Mulai Navigasi',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTransportOption(
      int index, IconData icon, String time, String dist) {
    bool isSelected = _selectedTransportMode == index;

    return InkWell(
      onTap: () => setState(() => _selectedTransportMode = index),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryBlue.withOpacity(0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppTheme.primaryBlue : Colors.transparent,
          ),
        ),
        child: Column(
          children: [
            Icon(icon,
                color: isSelected ? AppTheme.primaryBlue : Colors.grey[600]),
            const SizedBox(height: 4),
            Text(
              time,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 12,
                color: isSelected ? AppTheme.primaryBlue : Colors.grey[800],
              ),
            ),
            Text(
              dist,
              style: TextStyle(fontSize: 10, color: Colors.grey[600]),
            ),
          ],
        ),
      ),
    );
  }
}

class RouteMapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Map Canvas
    final Paint bgPaint = Paint()..color = const Color(0xFFE2E8F0);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    // Roads
    final Paint roadPaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 14.0;
    
    Path roadPath = Path();
    roadPath.moveTo(size.width * 0.2, size.height * 0.7);
    roadPath.quadraticBezierTo(
      size.width * 0.5,
      size.height * 0.5,
      size.width * 0.8,
      size.height * 0.3,
    );
    canvas.drawPath(roadPath, roadPaint);

    // Blue Navigation Line
    final Paint routeLinePaint = Paint()
      ..color = AppTheme.primaryBlue
      ..strokeWidth = 6.0
      ..style = PaintingStyle.stroke;
    canvas.drawPath(roadPath, routeLinePaint);

    // Start Dot (User)
    canvas.drawCircle(
        Offset(size.width * 0.2, size.height * 0.7), 10, Paint()..color = AppTheme.primaryBlue);

    // End Marker Pin (Destination)
    canvas.drawCircle(
        Offset(size.width * 0.8, size.height * 0.3), 12, Paint()..color = Colors.red);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
