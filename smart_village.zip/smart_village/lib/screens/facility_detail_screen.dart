import 'package:flutter/material.dart';
import '../models/facility.dart';
import '../theme.dart';
import '../services/location_service.dart';
import 'route_screen.dart';

class FacilityDetailScreen extends StatefulWidget {
  final Facility facility;

  const FacilityDetailScreen({super.key, required this.facility});

  @override
  State<FacilityDetailScreen> createState() => _FacilityDetailScreenState();
}

class _FacilityDetailScreenState extends State<FacilityDetailScreen> {
  late bool _isFavorite;

  @override
  void initState() {
    super.initState();
    _isFavorite = widget.facility.isFavorite;
  }

  @override
  Widget build(BuildContext context) {
    final String distanceStr =
        LocationService.formatDistance(widget.facility.distanceInKm);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // Banner Image & App Bar
          SliverAppBar(
            expandedHeight: 220.0,
            pinned: true,
            leading: Container(
              margin: const EdgeInsets.all(8),
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: const Icon(Icons.arrow_back, color: AppTheme.primaryDark),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            actions: [
              Container(
                margin: const EdgeInsets.only(right: 16, top: 8, bottom: 8),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  icon: Icon(
                    _isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: _isFavorite ? Colors.red : AppTheme.primaryDark,
                  ),
                  onPressed: () {
                    setState(() {
                      _isFavorite = !_isFavorite;
                      widget.facility.isFavorite = _isFavorite;
                    });
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(_isFavorite
                            ? '${widget.facility.name} ditambahkan ke favorit'
                            : '${widget.facility.name} dihapus dari favorit'),
                        duration: const Duration(seconds: 1),
                      ),
                    );
                  },
                ),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Image.network(
                widget.facility.imageUrl,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    color: AppTheme.primaryBlue.withOpacity(0.1),
                    child: const Icon(Icons.local_hospital,
                        size: 80, color: AppTheme.primaryBlue),
                  );
                },
              ),
            ),
          ),

          // Detail Content (Matching Image 2 Screen 5)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Name
                  Text(
                    widget.facility.name,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryDark,
                    ),
                  ),
                  const SizedBox(height: 6),

                  // Rating & Distance
                  Row(
                    children: [
                      const Icon(Icons.star,
                          size: 16, color: AppTheme.ratingGold),
                      const SizedBox(width: 4),
                      Text(
                        '${widget.facility.rating} (${widget.facility.reviewCount} ulasan)',
                        style: TextStyle(
                            fontSize: 13, color: Colors.grey[700]),
                      ),
                      const SizedBox(width: 16),
                      const Icon(Icons.near_me,
                          size: 14, color: AppTheme.primaryBlue),
                      const SizedBox(width: 4),
                      Text(
                        distanceStr,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryBlue,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Operating Hours Badge
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.openGreenBg,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.circle,
                            size: 8, color: AppTheme.openGreenText),
                        const SizedBox(width: 6),
                        Text(
                          widget.facility.operatingHours,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.openGreenText,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Address
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.location_on,
                          size: 18, color: AppTheme.primaryBlue),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          widget.facility.address,
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.grey[800],
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Divider(),
                  ),

                  // Section: Jenis Pelayanan (8 Icon Grid as seen in Screen 5)
                  const Text(
                    'Jenis Pelayanan',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryDark,
                    ),
                  ),
                  const SizedBox(height: 16),

                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 4,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 16,
                    childAspectRatio: 0.9,
                    children: [
                      _buildServiceGridTile(
                          'Poliklinik', Icons.local_hospital_outlined, AppTheme.primaryBlue),
                      _buildServiceGridTile(
                          'IGD', Icons.medical_services_outlined, Colors.red),
                      _buildServiceGridTile(
                          'Rawat Inap', Icons.king_bed_outlined, Colors.blue),
                      _buildServiceGridTile(
                          'Laboratorium', Icons.science_outlined, Colors.indigo),
                      _buildServiceGridTile(
                          'Radiologi', Icons.camera_outlined, Colors.teal),
                      _buildServiceGridTile(
                          'Farmasi', Icons.medication_outlined, Colors.green),
                      _buildServiceGridTile(
                          'Rehabilitasi', Icons.favorite_outline, Colors.purple),
                      _buildServiceGridTile(
                          'Lainnya', Icons.more_horiz, Colors.grey),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),

      // Bottom Primary Action Button
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: SizedBox(
          width: double.infinity,
          height: 50,
          child: ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => RouteScreen(facility: widget.facility),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryBlue,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25),
              ),
              elevation: 0,
            ),
            child: const Text(
              'Lihat di Peta',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildServiceGridTile(String title, IconData icon, Color color) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 22),
        ),
        const SizedBox(height: 6),
        Text(
          title,
          style: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            color: AppTheme.primaryDark,
          ),
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }
}
