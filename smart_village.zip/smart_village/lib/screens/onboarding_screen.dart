import 'package:flutter/material.dart';
import '../theme.dart';
import 'main_shell.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
          child: Column(
            children: [
              const SizedBox(height: 10),

              // 1. Smart Village Logo Emblem (Matching Screen 1 Top)
              Container(
                width: 70,
                height: 70,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.primaryBlue.withOpacity(0.15),
                      blurRadius: 15,
                      offset: const Offset(0, 4),
                    ),
                  ],
                  border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.2), width: 2),
                ),
                child: Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Icon(
                        Icons.location_on_rounded,
                        color: Colors.green[600],
                        size: 42,
                      ),
                      const Positioned(
                        top: 10,
                        child: Icon(
                          Icons.add,
                          color: Colors.redAccent,
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // 2. Title & Subtitle (Matching Screen 1)
              const Text(
                'Sehat Bersama\nSmart Village',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryDark,
                  height: 1.25,
                ),
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Text(
                  'Temukan lokasi Klinik, Puskesmas dan Rumah Sakit terdekat dengan mudah.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey[600],
                    height: 1.4,
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // 3. Center Village & Hospital Landscape Vector Illustration (Matching Screen 1)
              Expanded(
                child: Center(
                  child: AspectRatio(
                    aspectRatio: 1.1,
                    child: CustomPaint(
                      painter: OnboardingIllustrationPainter(),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // 4. Action Buttons ("Mulai" & "Masuk")
              Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const MainShell(),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryBlue,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                      child: const Text(
                        'Mulai',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  TextButton(
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const MainShell(),
                        ),
                      );
                    },
                    child: const Text(
                      'Masuk',
                      style: TextStyle(
                        color: AppTheme.primaryBlue,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Custom Painter for Smart Village Hospital Landscape Vector Illustration (Matching Screen 1)
class OnboardingIllustrationPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Sky Background Gradient
    final Rect rect = Offset.zero & size;
    final Paint skyPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFFE0F2FE), Color(0xFFBAE6FD)],
      ).createShader(rect);
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(24)),
      skyPaint,
    );

    // Sun
    final Paint sunPaint = Paint()..color = const Color(0xFFFEF08A);
    canvas.drawCircle(Offset(size.width * 0.8, size.height * 0.25), 28, sunPaint);

    // Green Hills Background
    final Paint hillPaintFar = Paint()..color = const Color(0xFF86EFAC);
    final Path hillFarPath = Path()
      ..moveTo(0, size.height * 0.6)
      ..quadraticBezierTo(size.width * 0.3, size.height * 0.45, size.width * 0.6, size.height * 0.58)
      ..quadraticBezierTo(size.width * 0.8, size.height * 0.65, size.width, size.height * 0.55)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height);
    canvas.drawPath(hillFarPath, hillPaintFar);

    final Paint hillPaintNear = Paint()..color = const Color(0xFF4ADE80);
    final Path hillNearPath = Path()
      ..moveTo(0, size.height * 0.7)
      ..quadraticBezierTo(size.width * 0.5, size.height * 0.55, size.width, size.height * 0.68)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height);
    canvas.drawPath(hillNearPath, hillPaintNear);

    // Hospital Building (Center)
    final Paint buildingPaint = Paint()..color = Colors.white;
    final Rect buildingRect = Rect.fromLTWH(
      size.width * 0.32,
      size.height * 0.38,
      size.width * 0.36,
      size.height * 0.32,
    );
    canvas.drawRect(buildingRect, buildingPaint);

    // Hospital Roof (Red)
    final Paint roofPaint = Paint()..color = const Color(0xFFEF4444);
    final Path roofPath = Path()
      ..moveTo(size.width * 0.3, size.height * 0.38)
      ..lineTo(size.width * 0.5, size.height * 0.28)
      ..lineTo(size.width * 0.7, size.height * 0.38)
      ..close();
    canvas.drawPath(roofPath, roofPaint);

    // Medical Red Cross on Hospital Building
    final Paint crossPaint = Paint()..color = const Color(0xFFEF4444);
    canvas.drawRect(
      Rect.fromLTWH(size.width * 0.47, size.height * 0.42, size.width * 0.06, size.height * 0.12),
      crossPaint,
    );
    canvas.drawRect(
      Rect.fromLTWH(size.width * 0.44, size.height * 0.45, size.width * 0.12, size.height * 0.06),
      crossPaint,
    );

    // Windows
    final Paint windowPaint = Paint()..color = const Color(0xFF38BDF8);
    for (double x in [0.36, 0.58]) {
      for (double y in [0.44, 0.56]) {
        canvas.drawRect(
          Rect.fromLTWH(size.width * x, size.height * y, size.width * 0.06, size.height * 0.06),
          windowPaint,
        );
      }
    }

    // Winding Road in Foreground
    final Paint roadPaint = Paint()
      ..color = const Color(0xFF94A3B8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 36.0;
    final Path roadPath = Path()
      ..moveTo(size.width * 0.5, size.height * 0.7)
      ..quadraticBezierTo(size.width * 0.2, size.height * 0.85, size.width * 0.5, size.height);
    canvas.drawPath(roadPath, roadPaint);

    // Road Center Dash Lines
    final Paint dashPaint = Paint()
      ..color = Colors.amber
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0;
    canvas.drawPath(roadPath, dashPaint);

    // Small Village Houses & Trees
    final Paint treeTrunk = Paint()..color = const Color(0xFF78350F);
    final Paint treeLeaves = Paint()..color = const Color(0xFF15803D);

    // Tree Left
    canvas.drawRect(Rect.fromLTWH(size.width * 0.15, size.height * 0.62, 8, 20), treeTrunk);
    canvas.drawCircle(Offset(size.width * 0.15 + 4, size.height * 0.58), 16, treeLeaves);

    // Tree Right
    canvas.drawRect(Rect.fromLTWH(size.width * 0.8, size.height * 0.62, 8, 20), treeTrunk);
    canvas.drawCircle(Offset(size.width * 0.8 + 4, size.height * 0.58), 16, treeLeaves);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
