import 'package:flutter/material.dart';
import '../models/facility.dart';
import '../theme.dart';
import 'home_screen.dart';
import 'facility_list_screen.dart';
import 'map_screen.dart';
import 'favorite_screen.dart';
import 'profile_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;
  String _selectedCategoryFilter = 'Semua';
  Facility? _selectedFacilityForMap;

  void _navigateToTab(int index, [String? category]) {
    setState(() {
      _currentIndex = index;
      if (category != null) {
        _selectedCategoryFilter = category;
      }
    });
  }

  void _onSelectFacilityForMap(Facility facility) {
    setState(() {
      _selectedFacilityForMap = facility;
      _currentIndex = 1; // Jump to Map Tab
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      HomeScreen(onNavigateTab: _navigateToTab),
      MapScreen(preselectedFacility: _selectedFacilityForMap),
      const FavoriteScreen(),
      const ProfileScreen(),
      // Hidden subscreen accessible via filter / see all
      FacilityListScreen(
        initialCategory: _selectedCategoryFilter,
        onSelectFacilityOnMap: _onSelectFacilityForMap,
      ),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: pages,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex > 3 ? 0 : _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.white,
          selectedItemColor: AppTheme.primaryBlue,
          unselectedItemColor: Colors.grey[500],
          selectedLabelStyle:
              const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
          unselectedLabelStyle: const TextStyle(fontSize: 11),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              activeIcon: Icon(Icons.home_rounded, color: AppTheme.primaryBlue),
              label: 'Beranda',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.map_outlined),
              activeIcon: Icon(Icons.map_rounded, color: AppTheme.primaryBlue),
              label: 'Peta',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.favorite_border_rounded),
              activeIcon: Icon(Icons.favorite_rounded, color: AppTheme.primaryBlue),
              label: 'Favorit',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline_rounded),
              activeIcon: Icon(Icons.person_rounded, color: AppTheme.primaryBlue),
              label: 'Profil',
            ),
          ],
        ),
      ),
    );
  }
}
