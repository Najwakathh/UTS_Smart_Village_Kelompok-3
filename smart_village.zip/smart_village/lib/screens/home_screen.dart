import 'package:flutter/material.dart';
import '../models/facility.dart';
import '../data/facility_data.dart';
import '../theme.dart';
import '../services/location_service.dart';
import '../services/geofence_service.dart';
import '../widgets/hospital_image_widget.dart';
import 'facility_detail_screen.dart';
import 'lockscreen_notification_screen.dart';
import 'geofence_alert_screen.dart';

class HomeScreen extends StatefulWidget {
  final Function(int, String?) onNavigateTab;

  const HomeScreen({super.key, required this.onNavigateTab});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late List<Facility> _facilities;
  final locationService = LocationService();
  final geofenceService = GeofenceService();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
    final list = FacilityData.getInitialFacilities();
    for (var f in list) {
      f.distanceInKm = LocationService.calculateDistance(
        locationService.currentUserLat,
        locationService.currentUserLng,
        f.latitude,
        f.longitude,
      );
      f.isInGeofence = geofenceService.isWithinGeofence(f.latitude, f.longitude);
    }
    list.sort((a, b) => a.distanceInKm.compareTo(b.distanceInKm));
    setState(() {
      _facilities = list;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. Header (Logo + Title + Location + Notification)
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppTheme.primaryBlue.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Icon(
                        Icons.medical_services_rounded,
                        color: AppTheme.primaryBlue,
                        size: 24,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Smart Village',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.primaryDark,
                          ),
                        ),
                        Row(
                          children: [
                            const Icon(
                              Icons.location_on,
                              size: 13,
                              color: AppTheme.primaryBlue,
                            ),
                            const SizedBox(width: 2),
                            Text(
                              'Kabupaten X',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey[600],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(
                      Icons.notifications_active_rounded,
                      color: AppTheme.primaryBlue,
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              const LockscreenNotificationScreen(),
                        ),
                      );
                    },
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Quick LBS & Geofencing Feature Bar (Screen 6 & Screen 10 triggers)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.primaryBlue.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.2)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.radar, color: AppTheme.primaryBlue, size: 18),
                        SizedBox(width: 6),
                        Text(
                          'LBS & Geofencing System Active',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.primaryDark,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      const LockscreenNotificationScreen(),
                                ),
                              );
                            },
                            icon: const Icon(Icons.notifications, size: 14),
                            label: const Text('Notif Lockscreen',
                                style: TextStyle(fontSize: 11)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: AppTheme.primaryBlue,
                              elevation: 0,
                              side: const BorderSide(color: AppTheme.primaryBlue),
                              padding: const EdgeInsets.symmetric(vertical: 8),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      const GeofenceAlertScreen(),
                                ),
                              );
                            },
                            icon: const Icon(Icons.location_on, size: 14),
                            label: const Text('Alert Geofence',
                                style: TextStyle(fontSize: 11)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primaryBlue,
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(vertical: 8),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 2. Search Bar
              GestureDetector(
                onTap: () => widget.onNavigateTab(1, null),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.grey.shade200),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.02),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.search, color: Colors.grey, size: 20),
                      const SizedBox(width: 10),
                      Text(
                        'Cari rumah sakit, puskesmas, klinik...',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // 3. Category Icons Horizontal Row (4 items)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildCategoryIconButton(
                    title: 'Rumah Sakit',
                    icon: Icons.local_hospital_rounded,
                    bgColor: AppTheme.rsRed,
                    onTap: () => widget.onNavigateTab(1, 'Rumah Sakit'),
                  ),
                  _buildCategoryIconButton(
                    title: 'Puskesmas',
                    icon: Icons.add_box_rounded,
                    bgColor: AppTheme.puskesmasGreen,
                    onTap: () => widget.onNavigateTab(1, 'Puskesmas'),
                  ),
                  _buildCategoryIconButton(
                    title: 'Klinik',
                    icon: Icons.medical_services_rounded,
                    bgColor: AppTheme.klinikBlue,
                    onTap: () => widget.onNavigateTab(1, 'Klinik'),
                  ),
                  _buildCategoryIconButton(
                    title: 'Semua',
                    icon: Icons.grid_view_rounded,
                    bgColor: AppTheme.semuaOrange,
                    onTap: () => widget.onNavigateTab(1, 'Semua'),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // 4. Section: Layanan Kesehatan Terdekat
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Layanan Kesehatan Terdekat',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryDark,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => widget.onNavigateTab(1, 'Semua'),
                    child: const Row(
                      children: [
                        Text(
                          'Lihat Semua',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppTheme.primaryBlue,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 2),
                        Icon(
                          Icons.chevron_right,
                          size: 16,
                          color: AppTheme.primaryBlue,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // 5. Vertical List of Facilities (Matching Image 2 Screen 2)
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _facilities.length,
                itemBuilder: (context, index) {
                  final facility = _facilities[index];
                  return _buildFacilityItemCard(context, facility);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryIconButton({
    required String title,
    required IconData icon,
    required Color bgColor,
    required VoidCallback onTap,
  }) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: bgColor,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(icon, color: Colors.white, size: 28),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          title,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: AppTheme.primaryDark,
          ),
        ),
      ],
    );
  }

  Widget _buildFacilityItemCard(BuildContext context, Facility facility) {
    final String distanceStr =
        LocationService.formatDistance(facility.distanceInKm);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.grey.shade200),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => FacilityDetailScreen(facility: facility),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              // Offline & Online Robust Hospital Image
              HospitalImageWidget(
                category: facility.category,
                width: 70,
                height: 70,
                borderRadius: 12,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      facility.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: AppTheme.primaryDark,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(Icons.near_me,
                            size: 12, color: AppTheme.primaryBlue),
                        const SizedBox(width: 4),
                        Text(
                          distanceStr,
                          style: const TextStyle(
                            fontSize: 11,
                            color: Colors.grey,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppTheme.openGreenBg,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.circle,
                                  size: 6, color: AppTheme.openGreenText),
                              SizedBox(width: 4),
                              Text(
                                'Buka',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: AppTheme.openGreenText,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),

                    // Service Tags (IGD, Poliklinik, Rawat Inap, etc.)
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: facility.services.take(3).map((service) {
                          return Container(
                            margin: const EdgeInsets.only(right: 6),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade100,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              service,
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.grey[700],
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
